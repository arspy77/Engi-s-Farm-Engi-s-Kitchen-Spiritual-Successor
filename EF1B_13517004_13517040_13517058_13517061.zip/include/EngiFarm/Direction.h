#ifndef DIRECTION_H
#define DIRECTION_H
/* Direction adalah kelas enum yang merepresentasikan gerakan pemain*/
enum class Direction {
    LEFT, RIGHT, UP, DOWN
};

#endif