#ifndef FARM_PRODUCT_H
#define FARM_PRODUCT_H

#include "Product.h"

/** Product yang didapat dari hasil interact / kill*/
class FarmProduct : public Product {
};

#endif