var searchData=
[
  ['ostrich',['Ostrich',['../classOstrich.html',1,'']]],
  ['ostrichegg',['OstrichEgg',['../classOstrichEgg.html',1,'']]]
];
