var searchData=
[
  ['ncollumncell',['nCollumnCell',['../classLivingThing.html#ab55191dc49dadfa2ac3e0dfcb25158b5',1,'LivingThing']]],
  ['nrowcell',['nRowCell',['../classLivingThing.html#a9bd85c97cefc60bf4dde7d46f58ce314',1,'LivingThing']]]
];
