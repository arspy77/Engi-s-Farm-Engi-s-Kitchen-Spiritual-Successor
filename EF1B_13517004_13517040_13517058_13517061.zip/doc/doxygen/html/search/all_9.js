var searchData=
[
  ['kill',['kill',['../classPlayer.html#aa087012e6382b0b0e5bae07da83f7d5d',1,'Player']]]
];
