var searchData=
[
  ['isocupied',['isOcupied',['../classCell.html#accb53db13c513893657e5f9dbc4cbcfb',1,'Cell']]]
];
