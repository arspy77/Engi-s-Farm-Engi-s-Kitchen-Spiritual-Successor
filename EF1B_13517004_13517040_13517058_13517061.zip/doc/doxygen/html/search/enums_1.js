var searchData=
[
  ['category',['Category',['../classCell.html#a496e49fee3586107cc8f60229d1e943e',1,'Cell::Category()'],['../classProduct.html#a4be8926067abd593e348b753eedb9c6c',1,'Product::Category()']]]
];
