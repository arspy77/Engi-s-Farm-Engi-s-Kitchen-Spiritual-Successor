var searchData=
[
  ['draw',['Draw',['../classWorld.html#a9b69dbbd736dfe1725f9facec1254a68',1,'World']]],
  ['duck',['Duck',['../classDuck.html#a8a17fc5929fe3305392d34ba4636c7dd',1,'Duck']]]
];
