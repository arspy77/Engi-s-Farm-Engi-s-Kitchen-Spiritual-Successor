var searchData=
[
  ['beefchickenomelette',['BeefChickenOmelette',['../classBeefChickenOmelette.html#a70cdfdf865ae2cf9aec892dff9578ed0',1,'BeefChickenOmelette']]],
  ['beefmuttonsate',['BeefMuttonSate',['../classBeefMuttonSate.html#a12b2fa334f7cc5d97646f3b47097c443',1,'BeefMuttonSate']]]
];
