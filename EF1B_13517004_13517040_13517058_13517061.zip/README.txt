Compile : 
cmake .
make

Deskripsi Folder  :
src     : file-file implementasi
include : file-file header
doc     : file-file dokumentasi
test    : file-file yang digunakan untuk testing