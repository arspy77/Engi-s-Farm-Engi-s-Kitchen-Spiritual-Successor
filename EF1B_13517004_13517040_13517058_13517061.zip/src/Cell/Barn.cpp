#include "Barn.h"

Cell::Category Barn::getCategory() const
{
    return category;
}