#include "Well.h"
Cell::Category Well::getCategory() const
{
    return category;
}