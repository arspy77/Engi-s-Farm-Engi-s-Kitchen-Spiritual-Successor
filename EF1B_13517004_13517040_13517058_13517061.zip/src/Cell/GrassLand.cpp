#include "GrassLand.h"

Cell::Category GrassLand::getCategory() const
{
    return category;
}