#include "Mixer.h"
Cell::Category Mixer::getCategory() const
{
    return category;
}