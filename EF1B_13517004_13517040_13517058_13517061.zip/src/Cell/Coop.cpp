#include "Coop.h"

Cell::Category Coop::getCategory() const
{
    return category;
}