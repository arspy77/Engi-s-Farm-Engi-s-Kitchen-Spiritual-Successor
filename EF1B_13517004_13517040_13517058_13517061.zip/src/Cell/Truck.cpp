#include "Truck.h"
Cell::Category Truck::getCategory() const
{
    return category;
}