#include "SideProduct.h"
SideProduct::~SideProduct()
{

}