#include "DuckMeat.h"
int DuckMeat::getPrice() const
{
    return price;
}

/** Mengembalikan category dari produk */
Product::Category DuckMeat::getCategory() const
{
    return category;
}