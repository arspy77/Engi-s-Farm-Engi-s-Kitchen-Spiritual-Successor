#include "SheepMeat.h"
int SheepMeat::getPrice() const
{
    return price;
}

/** Mengembalikan category dari produk */
Product::Category SheepMeat::getCategory() const
{
    return category;
}