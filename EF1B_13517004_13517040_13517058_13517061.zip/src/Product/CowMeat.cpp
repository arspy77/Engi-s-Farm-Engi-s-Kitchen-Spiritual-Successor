#include "CowMeat.h"
int CowMeat::getPrice() const
{
    return price;
}

/** Mengembalikan category dari produk */
Product::Category CowMeat::getCategory() const
{
    return category;
}