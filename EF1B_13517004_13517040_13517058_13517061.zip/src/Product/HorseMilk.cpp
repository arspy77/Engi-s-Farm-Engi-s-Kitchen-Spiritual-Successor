#include "HorseMilk.h"
int HorseMilk::getPrice() const
{
    return price;
}

/** Mengembalikan category dari produk */
Product::Category HorseMilk::getCategory() const
{
    return category;
}