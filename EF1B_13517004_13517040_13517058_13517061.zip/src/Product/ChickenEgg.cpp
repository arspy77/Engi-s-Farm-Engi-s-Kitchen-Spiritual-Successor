#include "ChickenEgg.h"
int ChickenEgg::getPrice() const
{
    return price;
}

/** Mengembalikan category dari produk */
Product::Category ChickenEgg::getCategory() const
{
    return category;
}