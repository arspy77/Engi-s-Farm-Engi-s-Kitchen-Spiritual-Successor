#include "OstrichEgg.h"
int OstrichEgg::getPrice() const
{
    return price;
}

/** Mengembalikan category dari produk */
Product::Category OstrichEgg::getCategory() const
{
    return category;
}